import random

#rock : 1
#paper : 0
#scissor : -1

youDict = {"r":1,"p":0,"s":-1}
reverseDict = {1:"Rock", 0:"Paper", -1:"Scissor"}

user_score = 0
computer_score = 0

def game():
    global user_score, computer_score
    youStr = input("Enter your choice : (Choice should be r,p,s) ").lower()
    you = youDict[youStr]

    computer = random.choice([-1,0,1])

    print(f"You chose {reverseDict[you]}\nComputer chose {reverseDict[computer]}")

    if(computer==you):
        print("MATCH DRAW!")
    else:
        if(computer == -1 and you == 1):
            print("YOU WIN!")
            user_score+=1
        elif(computer == -1 and you == 0):
            print("YOU LOSE")
            computer_score+=1
        elif(computer == 1 and you == -1):
            print("YOU LOSE")
            computer_score+=1
        elif(computer == 1 and you == 0):
            print("YOU WIN")
            user_score+=1
        elif(computer == 0 and you == 1):
            print("YOU LOSE")
            computer_score+=1
        elif(computer == 0 and you == -1):
            print("YOU WIN")
            user_score+=1
        else:
            print("Something went wrong")

    # Display scores
    print(f"Current Scores:\n You: {user_score} | Computer: {computer_score}")

while True: 
    game()
    while True:
        play_again = input("Do you want to play another round? (yes/no): ").strip().lower()
        if play_again in ["yes", "y"]:
            break #ANOTHER ROUND STARTED 
        elif play_again in ["no", "n"]:
            print("Thanks for playing! Final Scores:")
            print(f"You: {user_score} | Computer: {computer_score}")
            if(user_score>computer_score):
                print("YOU WON THE SERIES!")
            elif(user_score<computer_score):
                print("YOU LOSE THE SERIES, TRY NEXT TIME!")
            else:
                print("MATCH DRAW")
            exit()  
        else:
            print("Invalid response. Please type 'yes' or 'no'.")
